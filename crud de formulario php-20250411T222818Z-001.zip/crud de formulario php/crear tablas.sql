-- Crear la base de datos 'registro_aspirantes'
CREATE DATABASE IF NOT EXISTS registro_aspirantes;

-- Seleccionar la base de datos
USE registro_aspirantes;

-- Crear la tabla 'aspirantes'
CREATE TABLE IF NOT EXISTS aspirantes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    semestre INT NOT NULL,
    direccion VARCHAR(255) NOT NULL,
    poblacion VARCHAR(100) NOT NULL,
    ciudad VARCHAR(100) NOT NULL,
    codigo_postal VARCHAR(10) NOT NULL,
    celular VARCHAR(15) NOT NULL,
    email VARCHAR(100) NOT NULL,
    alergico VARCHAR(50) NOT NULL,
    seguro VARCHAR(50) NOT NULL,
    avisar_nombre VARCHAR(100) NOT NULL,
    avisar_telefono VARCHAR(15) NOT NULL,
    recoger_nombre1 VARCHAR(100) NOT NULL,
    recoger_curp1 VARCHAR(18) NOT NULL,
    recoger_nombre2 VARCHAR(100) NOT NULL,
    recoger_curp2 VARCHAR(18) NOT NULL,
    tutor VARCHAR(100) NOT NULL,
    horario VARCHAR(50) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    edad INT NOT NULL
);

-- Crear la tabla 'usuarios'
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    rol VARCHAR(50) NOT NULL
);

-- Insertar datos de ejemplo en la tabla 'usuarios'
INSERT INTO usuarios (username, password, rol) VALUES
('admin', '$2y$10$TKh8H1Pz5b5t7n0ej5sMiuQaYxLh5J6RaM7P7jSKlzh...', 'admin'),
('usuario', '$2y$10$N9qo8uLOickgx2ZMRZo5e.HUKLZEr6Zro2LU2YzAxtP...', 'usuario');
