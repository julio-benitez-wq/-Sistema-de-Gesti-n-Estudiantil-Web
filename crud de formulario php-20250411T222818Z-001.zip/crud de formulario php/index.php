<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;700&family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
    <title>PHP - Formulario de Contacto</title>
</head>
<body>
    <div class="container">
        <h1>Contacto</h1>
        <form action="formulario.php" method="POST" id="formulario">
            <label for="name">Nombre:</label>
            <input type="text" name="nombre" placeholder="Ingresa tu nombre..." id="nombre" required>
            <label for="email" class="email">E-mail:</label>
            <input type="email" placeholder="Ingresa tu e-mail..." id="email" name="email" required>
            <label for="mensaje" class="message">Mensaje:</label>
            <textarea name="mensaje" cols="30" rows="5" placeholder="Escribe el mensaje a enviar..." required></textarea>
            <input type="submit" value="Enviar" class="enviar">
        </form>
    </div>
    <script src="js/index.js"></script>
</body>
</html>
