<?php
// Conexión a la base de datos
$servername = "localhost";
$database = "EjemploPHP";
$username = "root";
$password = ""; // Deja en blanco si no tienes contraseña para MySQL en XAMPP

// Crear la conexión
$conn = mysqli_connect($servername, $username, $password, $database);

// Verificar conexión
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Capturar valores del formulario
$nombre = $_POST['nombre'];
$email = $_POST['email'];
$mensaje = $_POST['mensaje'];

// Insertar datos en la tabla
$sql = "INSERT INTO Mensaje (nombre, correo, mensaje) VALUES ('$nombre', '$email', '$mensaje')";
if (mysqli_query($conn, $sql)) {
    echo "<h2>Mensaje enviado exitosamente</h2>";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

// Mostrar todos los mensajes
echo "<h1>Mensajes enviados</h1>";
echo "<div class='container'>";

$mensajes = mysqli_query($conn, "SELECT * FROM Mensaje");
while ($mensaje = mysqli_fetch_assoc($mensajes)) {
    echo "<div class='mensajeNuevo'>";
    echo "<p><span>Nombre: </span>" . htmlspecialchars($mensaje['nombre']) . "</p>";
    echo "<p><span>E-mail: </span>" . htmlspecialchars($mensaje['correo']) . "</p>";
    echo "<p><span>Mensaje: </span>" . htmlspecialchars($mensaje['mensaje']) . "</p>";
    echo "</div>";
}

echo "</div>";

// Enlace para regresar al formulario
echo "<div class='flex'><a href='index.php'>Regresar al formulario</a></div>";

// Cerrar conexión
mysqli_close($conn);
?>
